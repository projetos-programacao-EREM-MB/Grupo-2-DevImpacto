// ======================================================
// COLA AQUI — SCRIPT PRINCIPAL
// ======================================================


// ======================================================
// INICIALIZAÇÃO
// ======================================================

window.addEventListener("load", function () {

    // Verifica se existe aviso do professor
    const aviso = localStorage.getItem("aviso_turma");

    if (aviso) {
        alert("📢 AVISO DO PROFESSOR:\n\n" + aviso);
    }

    // Mostra ranking atual no console
    const rank = JSON.parse(
        localStorage.getItem("ranking") || "{}"
    );

    console.log("🏆 Pontos atuais:", rank);

    // Atualiza os pontos na interface
    atualizarPontos();
});


// ======================================================
// SISTEMA DE PONTOS
// ======================================================

let pontos = parseInt(
    localStorage.getItem("pontos_totais") || "0"
);

let perguntasRespondidas = new Set();

let ultimaResposta = "";
let ultimoTempo = 0;


// ======================================================
// FUNÇÕES DE PONTOS
// ======================================================

function obterPontos() {

    return parseInt(
        localStorage.getItem("pontos_totais") || "0"
    );

}


function salvarPontos(valor) {

    pontos = valor;

    localStorage.setItem(
        "pontos_totais",
        pontos
    );

    atualizarPontos();

}


function adicionarPontos(valor) {

    const totalAtual = obterPontos();

    const novoTotal = totalAtual + valor;

    salvarPontos(novoTotal);

    console.log(
        `⭐ +${valor} pontos | Total: ${novoTotal}`
    );

}


function atualizarPontos() {

    const elemento = document.getElementById(
        "meus-pontos"
    );

    if (!elemento) return;

    elemento.innerText = obterPontos();

}


// Atualiza o contador periodicamente
setInterval(atualizarPontos, 1000);


// ======================================================
// PALAVRAS-CHAVE
// ======================================================

const palavrasChave = {

    "metáfora": [
        "metáfora",
        "comparação",
        "sentido figurado",
        "figura de linguagem"
    ],

    "fração": [
        "fração",
        "inverter",
        "multiplicar",
        "numerador",
        "denominador"
    ],

    "bhaskara": [
        "bhaskara",
        "delta",
        "fórmula",
        "formula",
        "equação"
    ],

    "revolução pernambucana": [
        "pernambucana",
        "1817",
        "independência",
        "recife"
    ],

    "default": []

};


// ======================================================
// VERIFICA SE A RESPOSTA TEM RELAÇÃO COM A PERGUNTA
// ======================================================

function temContexto(pergunta, resposta) {

    pergunta = pergunta.toLowerCase();
    resposta = resposta.toLowerCase();

    let chaves = [];

    for (let tema in palavrasChave) {

        if (tema === "default") continue;

        if (pergunta.includes(tema)) {

            chaves = palavrasChave[tema];

            break;
        }
    }

    // Se não encontrou um tema específico,
    // permite a resposta.
    if (chaves.length === 0) {
        return true;
    }

    return chaves.some(function (palavra) {

        return resposta.includes(palavra);

    });

}


// ======================================================
// TELA DO ALUNO — POSTAR DÚVIDA
// ======================================================

function postar() {

    const tituloEl =
        document.getElementById("titulo");

    const descEl =
        document.getElementById("desc");

    const materiaEl =
        document.getElementById("materia");

    const feed =
        document.getElementById("feed");


    // Evita erro caso a função seja executada
    // em uma página que não possui esses elementos.
    if (!tituloEl || !descEl || !materiaEl || !feed) {
        console.warn(
            "⚠️ Elementos da postagem não encontrados."
        );

        return;
    }


    const titulo =
        tituloEl.value.trim();

    const desc =
        descEl.value.trim();

    const materia =
        materiaEl.value;


    // Validação
    if (
        titulo.length < 5 ||
        desc.length < 10
    ) {

        alert(
            "❌ Explica melhor tua dúvida!"
        );

        return;
    }


    const id = Date.now();


    // Cria o card da nova dúvida
    const novaDuvida = document.createElement("div");

    novaDuvida.className = "duvida urgente";

    novaDuvida.dataset.id = id;

    novaDuvida.dataset.pergunta =
        titulo.toLowerCase();


    novaDuvida.innerHTML = `

        <span class="tag mono">
            ${materia} • agora • Você
        </span>

        <br>

        <b>${titulo}</b>

        <p style="
            color:#8B90A0;
            font-size:12px;
            margin-top:6px;
        ">
            ${desc}
        </p>

    `;


    // Coloca a dúvida no começo do feed
    feed.prepend(novaDuvida);


    // Limpa formulário
    tituloEl.value = "";

    descEl.value = "";


    console.log(
        "📚 Nova dúvida publicada:",
        titulo
    );

}


// ======================================================
// TELA DO ALUNO — RESPONDER
// ======================================================

function explicar(
    botao,
    id,
    textoPergunta
) {

    // Verifica se já respondeu
    if (perguntasRespondidas.has(id)) {

        alert(
            "❌ Tu já respondeu essa!"
        );

        return;
    }


    const resposta = prompt(
        `Responda: "${textoPergunta}"\n\n` +
        `Mínimo 20 letras e tem que ter ` +
        `a ver com o assunto:`
    );


    // Cancelou
    if (!resposta) {
        return;
    }


    const respostaLimpa =
        resposta.trim();


    // Verifica tamanho
    if (respostaLimpa.length < 20) {

        alert(
            "❌ Muito curto! Escreve uma explicação maior."
        );

        return;
    }


    // Verifica contexto
    if (
        !temContexto(
            textoPergunta,
            respostaLimpa
        )
    ) {

        alert(
            `❌ A resposta parece não ter relação ` +
            `com "${textoPergunta}"!`
        );

        return;
    }


    // Marca pergunta como respondida
    perguntasRespondidas.add(id);


    // ==================================================
    // GANHA 10 PONTOS
    // ==================================================

    adicionarPontos(10);


    // ==================================================
    // MOSTRA RESPOSTA NO CARD
    // ==================================================

    if (botao) {

        const respostaDiv =
            document.createElement("div");

        respostaDiv.style.cssText = `
            margin-top:10px;
            padding:10px;
            background:#0F1116;
            border:1px dashed #2CFF62;
            border-radius:4px;
        `;


        respostaDiv.innerHTML = `

            <p style="
                font-size:12px;
                margin:0;
            ">

                <b style="color:#2CFF62">
                    Sua resposta:
                </b>

                ${respostaLimpa}

            </p>

        `;


        // Coloca a resposta depois do botão
        botao.parentElement.appendChild(
            respostaDiv
        );


        // Esconde botão
        botao.style.display = "none";

    }


    alert(
        "✅ Boa! +10 pts"
    );

}


// ======================================================
// TELA DO PROFESSOR — ENVIAR AVISO
// ======================================================

function enviarAviso() {

    const tituloEl =
        document.getElementById("aviso-titulo");

    const textoEl =
        document.getElementById("aviso-texto");


    if (!tituloEl || !textoEl) {

        console.warn(
            "⚠️ Campos de aviso não encontrados."
        );

        return;
    }


    const titulo =
        tituloEl.value.trim();

    const texto =
        textoEl.value.trim();


    // Validação
    if (
        titulo.length < 3 ||
        texto.length < 5
    ) {

        alert(
            "❌ Preenche o título e o recado!"
        );

        return;
    }


    // Salva aviso
    const avisoCompleto =
        `${titulo}\n${texto}`;


    localStorage.setItem(
        "aviso_turma",
        avisoCompleto
    );


    localStorage.setItem(
        "ultimo_aprovado",
        "AVISO: " + titulo
    );


    // Limpa campos
    tituloEl.value = "";

    textoEl.value = "";


    // Atualiza log
    const log =
        document.getElementById(
            "log-validacoes"
        );


    if (log) {

        const item =
            document.createElement("div");

        item.className =
            "ranking-item mono";

        item.style.cssText = `
            font-size:11px;
            padding:6px 0;
        `;


        item.innerHTML = `

            <span>
                Você: ${titulo}
            </span>

            <b style="color:#FF5A1F">
                agora
            </b>

        `;


        log.prepend(item);

    }


    alert(
        "✅ Aviso enviado para a turma!\n\n" +
        titulo
    );

}


// ======================================================
// PROFESSOR — APROVAR RESPOSTA
// ======================================================

function aprovarResposta(
    id,
    nome,
    ptsTexto
) {

    const card =
        document.getElementById(id);


    if (!card) {

        console.warn(
            "⚠️ Card não encontrado:",
            id
        );

        return;
    }


    // ================================================
    // PONTOS DA APROVAÇÃO
    // ================================================

    const pontosGanhos = 15;

    adicionarPontos(pontosGanhos);


    // Salva informação
    localStorage.setItem(
        "ultimo_aprovado",
        `${nome} ganhou +${pontosGanhos}`
    );


    // ================================================
    // ALTERA CARD
    // ================================================

    card.style.borderLeft =
        "3px solid #2CFF62";


    card.innerHTML = `

        <div style="
            padding:20px;
            text-align:center;
            color:#2CFF62;
        "
        class="mono">

            ✅ APROVADO!

            <br>

            <span style="
                color:#F5F5F5;
                font-size:12px;
            ">
                ${nome} +${pontosGanhos} pts
            </span>

        </div>

    `;


    // ================================================
    // CONTADOR DE PENDENTES
    // ================================================

    const countPendentes =
        document.getElementById(
            "count-pendentes"
        );


    if (countPendentes) {

        const atual =
            parseInt(
                countPendentes.innerText
            ) || 0;


        countPendentes.innerText =
            Math.max(0, atual - 1);

    }


    // ================================================
    // CONTADOR DE VALIDADAS
    // ================================================

    const countValidadas =
        document.getElementById(
            "count-validadas"
        );


    if (countValidadas) {

        const atual =
            parseInt(
                countValidadas.innerText
            ) || 0;


        countValidadas.innerText =
            atual + 1;

    }


    // ================================================
    // LOG
    // ================================================

    const log =
        document.getElementById(
            "log-validacoes"
        );


    if (log) {

        const item =
            document.createElement("div");

        item.className =
            "ranking-item mono";

        item.style.cssText = `
            font-size:11px;
            padding:6px 0;
        `;


        item.innerHTML = `

            <span>
                Aprovado: ${nome}
            </span>

            <b style="color:#2CFF62">
                +${pontosGanhos} pts
            </b>

        `;


        log.prepend(item);

    }


    alert(
        `✅ Resposta aprovada!\n\n` +
        `${nome} recebeu +${pontosGanhos} pontos.`
    );

}


// ======================================================
// PROFESSOR — REJEITAR RESPOSTA
// ======================================================

function rejeitarResposta(id) {

    const motivo =
        prompt(
            "Qual o motivo da revisão?\n\n" +
            "Ex: Explicação incompleta, " +
            "erro no conceito..."
        );


    if (!motivo) {
        return;
    }


    const motivoLimpo =
        motivo.trim();


    if (motivoLimpo.length < 3) {

        alert(
            "❌ Escreve um motivo para a revisão."
        );

        return;
    }


    const card =
        document.getElementById(id);


    if (!card) {

        console.warn(
            "⚠️ Card não encontrado:",
            id
        );

        return;
    }


    card.style.borderLeft =
        "3px solid #FF3B30";


    card.innerHTML = `

        <div style="
            padding:20px;
            text-align:center;
            color:#FF3B30;
        "
        class="mono">

            📝 ENVIADO PARA REVISÃO

            <p style="
                color:#F5F5F5;
                font-family:Arial,sans-serif;
                font-size:12px;
                margin-top:8px;
            ">

                Motivo: ${motivoLimpo}

            </p>

        </div>

    `;


    // Salva último motivo
    localStorage.setItem(
        "ultima_revisao",
        motivoLimpo
    );

}


// ======================================================
// DEBUG
// ======================================================

console.log(
    "🚀 COLA AQUI carregado!"
);

console.log(
    "⭐ Pontos atuais:",
    obterPontos()
);