const videos = {

    matematica: {
        "Frações": "",
        "Equações": "",
        "Bhaskara": "",
        "Funções": "",
        "Geometria": ""
    },

    portugues: {
        "Interpretação de texto": "",
        "Metáfora": "",
        "Figuras de linguagem": "",
        "Gramática": "",
        "Redação": ""
    },

    fisica: {
        "Velocidade": "",
        "Aceleração": "",
        "Leis de Newton": "",
        "Energia": "",
        "Eletricidade": ""
    },

    quimica: {
        "Átomos": "",
        "Tabela periódica": "",
        "Ligações químicas": "",
        "Reações químicas": "",
        "Balanceamento": "wSe5GtlHYMc"
    },

    historia: {
        "Brasil Colônia": "",
        "Independência do Brasil": "",
        "Revolução Pernambucana": "5zERRwOmvdo",
        "Revolução Francesa": "",
        "Primeira Guerra Mundial": ""
    },

    biologia: {
        "Células": "",
        "Genética": "",
        "DNA": "",
        "Corpo humano": "",
        "Ecologia": ""
    },

    geografia: {
        "Clima": "",
        "Relevo": "",
        "Globalização": "",
        "População": "",
        "Geopolítica": ""
    }

};