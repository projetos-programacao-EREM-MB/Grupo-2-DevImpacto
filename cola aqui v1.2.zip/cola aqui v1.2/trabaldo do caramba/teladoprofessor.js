function aprovarResposta(id, nome, ptsTexto){
  let pontos = parseInt(ptsTexto) || 15;

  // Salva os pontos pro aluno ver na outra tela
  let ranking = JSON.parse(localStorage.getItem('ranking') || '{}');
  if(!ranking[nome]) ranking[nome] = 0;
  ranking[nome] += pontos;
  localStorage.setItem('ranking', JSON.stringify(ranking));
  localStorage.setItem('ultimo_aprovado', nome + ' ganhou +' + pontos);

  let card = document.getElementById(id);
  card.innerHTML = `<div style="padding:20px;text-align:center;color:#2CFF62" class="mono">✅ ${nome} recebeu +${pontos} PTS!</div>`;

  document.getElementById('count-pendentes').innerText = parseInt(document.getElementById('count-pendentes').innerText)-1;
  alert(`Pronto! ${nome} ganhou pontos. Vai na tela do aluno e dá F5`);
}
function rejeitarResposta(id){
  let motivo = prompt("Motivo da revisão?");
  if(motivo) document.getElementById(id).innerHTML = `<div style="padding:20px;text-align:center;color:#FF3B30" class="mono">📝 Revisão: ${motivo}</div>`;
}
function enviarAviso(){
  let t = document.getElementById('aviso-titulo').value;
  let m = document.getElementById('aviso-texto').value;
  if(!t ||!m) return alert("Preenche título e texto!");
  localStorage.setItem('aviso_turma', t + ": " + m);
  alert("✅ Aviso disparado!");
}

function enviarAviso(){
  let t = document.getElementById('aviso-titulo').value;
  let m = document.getElementById('aviso-texto').value;
  if(t.length < 2){ alert("Coloca um título!"); return; }
  localStorage.setItem('aviso_turma', t);
  localStorage.setItem('ultimo_aprovado', "AVISO: " + t);
  alert("✅ Aviso disparado: " + t);
  document.getElementById('aviso-titulo').value = "";
  document.getElementById('aviso-texto').value = "";
}

function aprovarResposta(id, nome, pts){
  let pontos = 15;
  // pega pontos antigos
  let total = parseInt(localStorage.getItem('pontos_totais') || "0");
  total += pontos;
  localStorage.setItem('pontos_totais', total);
  localStorage.setItem('ultimo_aprovado', nome + " ganhou +" + pontos);

  let card = document.getElementById(id);
  if(card){
    card.innerHTML = "<div style='padding:20px;text-align:center;color:#2CFF62;font-family:monospace'>✅ APROVADO!<br>" + nome + " +" + pontos + " pts</div>";
  }
  let c = document.getElementById('count-pendentes');
  if(c) c.innerText = parseInt(c.innerText)-1;
}

function rejeitarResposta(id){
  let card = document.getElementById(id);
  if(card) card.innerHTML = "<div style='padding:20px;text-align:center;color:#FF3B30;font-family:monospace'>📝 Enviado pra revisão</div>";
}

function pegarIdYoutube(url){
  let id = "";
  if(url.includes("v=")) id = url.split("v=")[1].split("&")[0];
  else if(url.includes("youtu.be/")) id = url.split("youtu.be/")[1].split("?")[0];
  else if(url.includes("embed/")) id = url.split("embed/")[1].split("?")[0];
  else id = url;
  return id;
}
function adicionarVideo(){
  let titulo = document.getElementById('tituloVideo').value;
  let materia = document.getElementById('materiaVideo').value;
  let link = document.getElementById('linkVideo').value;
  if(!titulo ||!link){ alert("Preencha titulo e link!"); return; }
  let id = pegarIdYoutube(link);
  let videos = JSON.parse(localStorage.getItem('videos_professor') || "[]");
  videos.unshift({ titulo, materia, id, prof: "@prof.voce" });
  localStorage.setItem('videos_professor', JSON.stringify(videos));
  alert("Publicado no feed TikTok ✅");
  document.getElementById('tituloVideo').value = "";
  document.getElementById('linkVideo').value = "";
}