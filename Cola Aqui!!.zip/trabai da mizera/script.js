window.onload = function(){
  let aviso = localStorage.getItem('aviso_turma');
  if(aviso) alert("📢 AVISO DO PROFESSOR: " + aviso);

  let rank = JSON.parse(localStorage.getItem('ranking') || '{}');
  console.log("Pontos atuais:", rank);
}

// ====== COMUM ======
let pontos = 0;
let perguntasRespondidas = new Set();
let ultimaResposta = "";
let ultimoTempo = 0;

const palavrasChave = {
  "metáfora": ["metáfora", "comparação", "sentido figurado", "figura de linguagem"],
  "fração": ["fração", "inverter", "multiplicar", "numerador", "denominador"],
  "bhaskara": ["bhaskara", "delta", "formula", "equação"],
  "revolução pernambucana": ["pernambucana", "1817", "independência", "recife"],
  "default": []
};

// ====== TELA DO ALUNO ======
function postar(){
  let tituloEl = document.getElementById('titulo');
  let descEl = document.getElementById('desc');
  if(!tituloEl) return;
  let titulo = tituloEl.value;
  let desc = descEl.value;
  if(titulo.length < 5 || desc.length < 10){ alert("Explica melhor tua dúvida!"); return; }
  let id = Date.now();
  let feed = document.getElementById('feed');
  if(feed){
    feed.innerHTML = `<div class="duvida urgente" data-id="${id}" data-pergunta="${titulo.toLowerCase()}"><span class="tag mono">${document.getElementById('materia').value} • agora • Você</span><br><b>${titulo}</b><p style="color:#8B90A0;font-size:12px">${desc}</p></div>` + feed.innerHTML;
  }
  tituloEl.value = ""; descEl.value = "";
}
function temContexto(pergunta, resposta){
  pergunta = pergunta.toLowerCase(); resposta = resposta.toLowerCase();
  let chaves = [];
  for(let tema in palavrasChave){ if(pergunta.includes(tema)) chaves = palavrasChave[tema]; }
  if(chaves.length === 0) return true;
  return chaves.some(p => resposta.includes(p));
}
function explicar(botao, id, textoPergunta){
  if(perguntasRespondidas.has(id)){ alert("❌ Tu já respondeu essa!"); return; }
  let resposta = prompt(`Responda: "${textoPergunta}"\nMínimo 20 letras e tem que ter a ver com o assunto:`);
  if(!resposta) return;
  if(resposta.length < 20){ alert("❌ Muito curto!"); return; }
  if(!temContexto(textoPergunta, resposta)){ alert(`❌ Nada a ver com "${textoPergunta}"!`); return; }
  perguntasRespondidas.add(id);
  pontos += 10;
  if(botao){
    botao.parentElement.innerHTML += `<div style="margin-top:10px;padding:10px;background:#0F1116;border:1px dashed #2CFF62;border-radius:4px"><p style="font-size:12px"><b style="color:#2CFF62">Sua resposta:</b> ${resposta}</p></div>`;
    botao.style.display = 'none';
  }
  alert("✅ Boa! +10 pts");
}

// ====== TELA DO PROFESSOR - É ISSO QUE TAVA FALTANDO ======
function enviarAviso(){
  let titulo = document.getElementById('aviso-titulo').value;
  let texto = document.getElementById('aviso-texto').value;
  if(titulo.length < 3 || texto.length < 5){ alert("Preenche título e recado!"); return; }
  alert(`✅ AVISO DISPARADO PARA 42 ALUNOS!\n\n${titulo}\n${texto}`);
  document.getElementById('aviso-titulo').value = "";
  document.getElementById('aviso-texto').value = "";
  let log = document.getElementById('log-validacoes');
  if(log) log.innerHTML = `<div class="ranking-item mono" style="font-size:11px;padding:6px 0;"><span>Você: ${titulo}</span><b style="color:#FF5A1F">agora</b></div>` + log.innerHTML;
}

function aprovarResposta(id, nome, pts){
  let card = document.getElementById(id);
  if(!card) return;
  card.style.borderLeft = "3px solid #2CFF62";
  card.innerHTML = `<div style="padding:15px;text-align:center"><p class="mono" style="color:#2CFF62;font-size:14px">✅ APROVADO!</p><p style="font-size:12px;margin-top:6px">${nome} ganhou ${pts}</p><p class="mono" style="font-size:10px;color:#8B90A0;margin-top:8px">Resposta liberada no feed dos alunos</p></div>`;
  
  // atualiza contador
  let count = document.getElementById('count-pendentes');
  if(count) count.innerText = parseInt(count.innerText) - 1;
  let validadas = document.getElementById('count-validadas');
  if(validadas) validadas.innerText = parseInt(validadas.innerText) + 1;
  
  let log = document.getElementById('log-validacoes');
  if(log) log.innerHTML = `<div class="ranking-item mono" style="font-size:11px;padding:6px 0;"><span>Aprovado: ${nome}</span><b style="color:#2CFF62">agora</b></div>` + log.innerHTML;
}

function rejeitarResposta(id){
  let motivo = prompt("Qual o motivo da revisão? Ex: Explicação incompleta, erro no conceito...");
  if(!motivo) return;
  let card = document.getElementById(id);
  if(!card) return;
  card.style.borderLeft = "3px solid #FF3B30";
  card.innerHTML = `<div style="padding:15px;text-align:center"><p class="mono" style="color:#FF3B30;font-size:14px">📝 ENVIADO PARA REVISÃO</p><p style="font-size:12px;margin-top:6px">Motivo: ${motivo}</p></div>`;
}

// ====== ADICIONA ISSO NO FINAL DO TEU script.js ATUAL ======

// atualiza os pontos sem precisar de F5
function atualizarPontos(){
  let el = document.getElementById('meus-pontos');
  if(el){
    let total = localStorage.getItem('pontos_totais') || "0";
    el.innerText = total;
  }
}
setInterval(atualizarPontos, 1000);
window.addEventListener('load', atualizarPontos);

// funcoes do professor que faltavam
function enviarAviso(){
  let t = document.getElementById('aviso-titulo').value;
  let m = document.getElementById('aviso-texto').value;
  if(t.length < 2){ alert("Coloca título!"); return; }
  localStorage.setItem('aviso_turma', t);
  localStorage.setItem('ultimo_aprovado', "AVISO: " + t);
  alert("✅ Aviso: " + t);
  document.getElementById('aviso-titulo').value = "";
  document.getElementById('aviso-texto').value = "";
}

function aprovarResposta(id, nome, ptsTexto){
  // NÃO apaga tua lógica de pontos, só soma mais 15
  let pontosGanhos = 15;
  let total = parseInt(localStorage.getItem('pontos_totais') || "0");
  total += pontosGanhos;
  localStorage.setItem('pontos_totais', total);
  localStorage.setItem('ultimo_aprovado', nome + " ganhou +" + pontosGanhos);

  // teu efeito visual de aprovado
  let card = document.getElementById(id);
  if(card){
    card.style.borderLeft = "3px solid #2CFF62";
    card.innerHTML = "<div style='padding:20px;text-align:center;color:#2CFF62' class='mono'>✅ APROVADO! " + nome + " +" + pontosGanhos + " pts</div>";
  }
  let count = document.getElementById('count-pendentes');
  if(count) count.innerText = parseInt(count.innerText)-1;
}

function rejeitarResposta(id){
  let card = document.getElementById(id);
  if(card){
    card.style.borderLeft = "3px solid #FF3B30";
    card.innerHTML = "<div style='padding:20px;text-align:center;color:#FF3B30' class='mono'>📝 Enviado pra revisão</div>";
  }
}