const videos = {

    matematica: {
        "Frações": "",
        "Equações": "",
        "Bhaskara": "",
        "Funções": "",
        "Geometria": ""
    },

    portugues: {
        "Interpretação de texto": "",
        "Metáfora": "n0e75nRstcU",
        "Figuras de linguagem": "n0e75nRstcU",
        "Gramática": "",
        "Redação": ""
    },

    fisica: {
        "Velocidade": "",
        "Aceleração": "",
        "Leis de Newton": "wJwDTUL6fz0",
        "Energia": "",
        "Eletricidade": ""
    },

    quimica: {
        "Átomos": "",
        "Tabela periódica": "RII_OM56t8I",
        "Ligações químicas": "",
        "Reações químicas": "",
        "Balanceamento": ""
    },

    historia: {
        "Brasil Colônia": "",
        "Independência do Brasil": "",
        "Revolução Pernambucana": "PsHbIDqZGM4",
        "Revolução Francesa": "",
        "Primeira Guerra Mundial": "Xi8Vj7aDcvg"
    },

    biologia: {
        "Células": "",
        "Genética": "",
        "DNA": "",
        "Corpo humano": "",
        "Ecologia": ""
    },

    geografia: {
        "Clima": "",
        "Relevo": "",
        "Globalização": "",
        "População": "",
        "Geopolítica": ""
    }

};