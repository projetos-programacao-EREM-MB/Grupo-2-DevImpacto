/* =========================================================
   COLA AQUI — CENTRAL DE AULAS
   ========================================================= */


/* =========================================================
   DADOS DAS MATÉRIAS
   ========================================================= */

const materias = {

    matematica: {
        nome: "Matemática",
        icone: "📐",
        descricao: "Equações, funções, geometria e cálculos.",

        assuntos: [
            "Frações",
            "Equações",
            "Bhaskara",
            "Funções",
            "Geometria"
        ]
    },


    portugues: {
        nome: "Português",
        icone: "📖",
        descricao: "Gramática, interpretação e literatura.",

        assuntos: [
            "Interpretação de texto",
            "Metáfora",
            "Figuras de linguagem",
            "Gramática",
            "Redação"
        ]
    },


    fisica: {
        nome: "Física",
        icone: "⚡",
        descricao: "Movimento, força, energia e eletricidade.",

        assuntos: [
            "Velocidade",
            "Aceleração",
            "Leis de Newton",
            "Energia",
            "Eletricidade"
        ]
    },


    quimica: {
        nome: "Química",
        icone: "🧪",
        descricao: "Átomos, moléculas e reações.",

        assuntos: [
            "Átomos",
            "Tabela periódica",
            "Ligações químicas",
            "Reações químicas",
            "Balanceamento"
        ]
    },


    historia: {
        nome: "História",
        icone: "🏛️",
        descricao: "Brasil, revoluções e civilizações.",

        assuntos: [
            "Brasil Colônia",
            "Independência do Brasil",
            "Revolução Pernambucana",
            "Revolução Francesa",
            "Primeira Guerra Mundial"
        ]
    },


    biologia: {
        nome: "Biologia",
        icone: "🧬",
        descricao: "Células, genética, corpo humano e ecologia.",

        assuntos: [
            "Células",
            "Genética",
            "DNA",
            "Corpo humano",
            "Ecologia"
        ]
    },


    geografia: {
        nome: "Geografia",
        icone: "🌎",
        descricao: "Mapas, clima, população e espaço geográfico.",

        assuntos: [
            "Clima",
            "Relevo",
            "Globalização",
            "População",
            "Geopolítica"
        ]
    }

};


/* =========================================================
   VÍDEOS
   =========================================================

   Coloque aqui o ID do vídeo do YouTube.

   Exemplo:

   https://www.youtube.com/watch?v=ABC123XYZ

   O ID seria:

   ABC123XYZ

   ========================================================= */

const videos = {

    matematica: {

        "Frações": "",
        "Equações": "",
        "Bhaskara": "",
        "Funções": "",
        "Geometria": ""

    },


    portugues: {

        "Interpretação de texto": "",
        "Metáfora": "",
        "Figuras de linguagem": "",
        "Gramática": "",
        "Redação": ""

    },


    fisica: {

        "Velocidade": "",
        "Aceleração": "",
        "Leis de Newton": "",
        "Energia": "",
        "Eletricidade": ""

    },


    quimica: {

        "Átomos": "",
        "Tabela periódica": "",
        "Ligações químicas": "",
        "Reações químicas": "",
        "Balanceamento": ""

    },


    historia: {

        "Brasil Colônia": "",
        "Independência do Brasil": "",
        "Revolução Pernambucana": "",
        "Revolução Francesa": "",
        "Primeira Guerra Mundial": ""

    },


    biologia: {

        "Células": "",
        "Genética": "",
        "DNA": "",
        "Corpo humano": "",
        "Ecologia": ""

    },


    geografia: {

        "Clima": "",
        "Relevo": "",
        "Globalização": "",
        "População": "",
        "Geopolítica": ""

    }

};


/* =========================================================
   ESTADO ATUAL
   ========================================================= */

let materiaAtual = "matematica";

let assuntoAtual = "";


/* =========================================================
   SELECIONAR MATÉRIA
   ========================================================= */

function selecionarAulaMateria(materia) {

    if (!materias[materia]) return;

    materiaAtual = materia;

    const dados = materias[materia];


    /* Remove seleção anterior */

    document
        .querySelectorAll(".aula-materia-card")
        .forEach(card => {
            card.classList.remove("ativa");
        });


    /* Seleciona o botão clicado */

    if (typeof event !== "undefined" && event.currentTarget) {

        event.currentTarget.classList.add("ativa");

    }


    /* Atualiza título */

    document.getElementById("titulo-materia").textContent =
        dados.icone + " " + dados.nome;


    /* Atualiza descrição */

    document.getElementById("descricao-materia").textContent =
        dados.descricao;


    /* Cria os assuntos */

    const assuntos =
        document.getElementById("assuntos");

    assuntos.innerHTML = "";


    dados.assuntos.forEach(assunto => {

        const botao =
            document.createElement("button");

        botao.textContent = assunto;

        botao.onclick = () => {
            abrirAula(assunto);
        };

        assuntos.appendChild(botao);

    });


    /* Reseta player */

    document.getElementById("player-area").innerHTML = `

        <div class="player-placeholder">

            <span>${dados.icone}</span>

            <h3>
                Escolha um assunto
            </h3>

            <p>
                Selecione um assunto de ${dados.nome}.
            </p>

        </div>

    `;


    /* Esconde feedback */

    document.getElementById("entendeu-card")
        .style.display = "none";


    document.getElementById("pergunta-final")
        .style.display = "none";


    /* Vai até o conteúdo */

    document
        .getElementById("conteudo-aulas")
        .scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

}


/* =========================================================
   ABRIR AULA
   ========================================================= */

function abrirAula(assunto) {

    assuntoAtual = assunto;

    const player =
        document.getElementById("player-area");


    const videoId =
        videos[materiaAtual]?.[assunto];


    /* =====================================================
       SE NÃO EXISTIR VÍDEO AINDA
       ===================================================== */

    if (!videoId) {

        player.innerHTML = `

            <div class="player-placeholder">

                <span>
                    🎥
                </span>

                <h3>
                    Aula em preparação
                </h3>

                <p>
                    Ainda estamos adicionando uma aula
                    para <strong>${assunto}</strong>.
                </p>

            </div>

        `;

        document.getElementById("entendeu-card")
            .style.display = "none";

        document.getElementById("pergunta-final")
            .style.display = "none";

        return;
    }


    /* =====================================================
       PLAYER REAL DO YOUTUBE
       ===================================================== */

    player.innerHTML = `

        <div class="video-real">

            <div class="youtube-player">

                <iframe
                    src="https://www.youtube.com/embed/${videoId}?rel=0"
                    title="Aula de ${assunto}"
                    frameborder="0"
                    allow="
                        accelerometer;
                        autoplay;
                        clipboard-write;
                        encrypted-media;
                        gyroscope;
                        picture-in-picture;
                        web-share
                    "
                    allowfullscreen>
                </iframe>

            </div>


            <div class="video-info-large">

                <span class="mono">
                    ${materias[materiaAtual].icone}
                    ${materias[materiaAtual].nome.toUpperCase()}
                </span>

                <h2>
                    ${assunto}
                </h2>

                <p>
                    Assista à explicação com calma.
                    Quando terminar, diga se a aula
                    resolveu sua dúvida.
                </p>

            </div>

        </div>

    `;


    /* Mostra "entendeu?" */

    document.getElementById("entendeu-card")
        .style.display = "flex";


    /* Esconde pergunta */

    document.getElementById("pergunta-final")
        .style.display = "none";


    /* Vai para o player */

    player.scrollIntoView({
        behavior: "smooth",
        block: "center"
    });

}


/* =========================================================
   ENTENDI
   ========================================================= */

function entendeuAula() {

    const card =
        document.getElementById("entendeu-card");


    card.innerHTML = `

        <div>

            <span
                class="mono"
                style="color:#2CFF62;">

                ✓ AULA CONCLUÍDA

            </span>

            <h3>
                Boa! Você entendeu. 🎉
            </h3>

            <p>
                A dúvida sobre
                <strong>${assuntoAtual}</strong>
                foi resolvida.
            </p>

        </div>

    `;

}


/* =========================================================
   NÃO ENTENDI
   ========================================================= */

function naoEntendeu() {

    const pergunta =
        document.getElementById("pergunta-final");


    pergunta.style.display = "block";


    pergunta.scrollIntoView({
        behavior: "smooth",
        block: "center"
    });

}